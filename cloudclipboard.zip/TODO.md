    - [x] Start to convert to Chrome extension research required. 

    - [x] Adding manifest.json

    - [x] Adding CSS and JS files to local

    - [x] Add button functionality through JS and not in HTML

    - [x] Popup does not seem to be popping up - Fix event listeners instead of attrib update and add function () 

    - [x] Uninstall Ionic 
    
    - [x] Add Basic PWA functionality

    - [ ] Make UI better 
    
    - [x] Host frontend somewhere so people can download the PWA. 

    - [x] use domain and point it to frontend and backend this will allow us to use cookies on the PWA 

    - [x] Get basic functionality working on Phones and Computers

    - [ ] Research Notifications

    - [ ] Service Worker needs to send a notification when data gets sent

